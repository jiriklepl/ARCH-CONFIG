#!/bin/sh

zenity --entry --class Open --title "Open Zathura" --text "Open a document in Zathura" | \
if read x; then zathura "$x"; fi