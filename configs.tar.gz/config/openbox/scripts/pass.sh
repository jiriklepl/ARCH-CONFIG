zenity --entry --class "Password" --title "Get Password" --text "Get Password for:" | \
if read where; then pass "$where" | xclip -selection clipboard; fi
