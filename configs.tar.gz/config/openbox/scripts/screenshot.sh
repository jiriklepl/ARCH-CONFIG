#!/bin/sh
output=$(slop --noopengl -qlc "1,1,1,.5" -f "%i %g")
echo "$output" | if read i g; then 
    shotgun -i $i -g $g - | feh -j ~/Pictures -
fi
